var searchData=
[
  ['b',['b',['../namespacesolver.html#a99565d1c8ed5142211b78fe3ccca060b',1,'solver']]]
];
