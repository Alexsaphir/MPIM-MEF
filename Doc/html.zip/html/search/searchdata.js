var indexSectionsWithContent =
{
  0: "abcdfgilnpstuw",
  1: "s",
  2: "cs",
  3: "abcdfgilnpstw",
  4: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fonctions",
  4: "Pages"
};

