var searchData=
[
  ['number_5fitem_5fon_5fline',['number_item_on_line',['../namespaceskyline.html#a9f07218be321c12bea1d84f6b629e346',1,'skyline']]]
];
