var searchData=
[
  ['trapza',['trapza',['../namespacesolver.html#a5cdc774a6979796cb6b072b2fbb0e5af',1,'solver']]],
  ['trapzf',['trapzf',['../namespacesolver.html#adb6590794b23eaed708cd2e42adac550',1,'solver']]]
];
